# MITRE ATT&CK Mapping

| Detection | SPL Query | MITRE Technique | Technique ID |
|---|---|---|---|
| Brute-Force Login Detection | `03_brute_force_detection.spl` | Brute Force | T1110 |
| Traffic Spike / DDoS Pattern | `04_traffic_spike_detection.spl` | Network Denial of Service | T1498 |
| Error Spike Detection | `05_error_spike_detection.spl` | (Operational — not an attack technique, used for service health monitoring) | N/A |

This mapping shows how raw log analysis in Splunk ties back to recognized
real-world attacker behavior, rather than being arbitrary threshold-based alerts.
