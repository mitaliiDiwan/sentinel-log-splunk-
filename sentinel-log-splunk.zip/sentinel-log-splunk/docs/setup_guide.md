# Setup Guide

## Prerequisites
- Splunk Enterprise (free trial or licensed instance) installed and running

## Steps

1. **Upload the sample data**
   - Go to `Settings → Add Data → Upload`
   - Select `access_logs.log` from the `data/` folder
   - Source type: `access_combined`
   - Index: `main` (or create a custom index, e.g. `web_logs`)
   - Submit

2. **Verify the data loaded correctly**
   ```
   index=main source="access_logs.log"
   ```
   You should see ~4000 events spanning 7 days.

3. **Run the detection queries**
   Open each `.spl` file in `spl-queries/` and paste the query into Splunk's
   Search & Reporting app. Run each one and review the results.

4. **Build the dashboard**
   For each query result, click `Save As → Dashboard Panel` and add it to a
   single dashboard (e.g. "Web Traffic Analytics Dashboard").

5. **Import the dashboard (optional)**
   The exported dashboard definition is in `dashboard/dashboard_export.json`.
   This can be used as a reference for recreating the dashboard layout in
   Dashboard Studio.

## Notes
- All queries assume `index=main`. Adjust the index name if you used a custom one.
- The sample data includes 3 intentional anomalies for the detections to catch:
  brute-force login attempts, a traffic spike from a single IP, and a server
  error spike.
